package br.unicamp.ic.aviacaoverde;

public class Aeronave {

	private Integer capacidadeTotal;

	public Integer getCapacidadeTotal() {
		return capacidadeTotal;
	}

	public void setCapacidadeTotal(Integer capacidadeTotal) {
		this.capacidadeTotal = capacidadeTotal;
	}

}
