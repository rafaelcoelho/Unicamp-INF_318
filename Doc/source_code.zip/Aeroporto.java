package br.unicamp.ic.aviacaoverde;

public class Aeroporto {

	private String nomeCidade;

	public String getNomeCidade() {
		return nomeCidade;
	}

	public void setNomeCidade(String nomeCidade) {
		this.nomeCidade = nomeCidade;
	}

}
